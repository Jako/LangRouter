<?php
$_lang['setting_langrouter.debug'] = 'Debug';
$_lang['setting_langrouter.debug_desc'] = 'Log debug informations in MODX error log.';

