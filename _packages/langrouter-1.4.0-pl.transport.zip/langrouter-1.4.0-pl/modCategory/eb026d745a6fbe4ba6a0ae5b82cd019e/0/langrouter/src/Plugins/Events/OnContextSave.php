<?php
/**
 * @package langrouter
 * @subpackage plugin
 */

namespace TreehillStudio\LangRouter\Plugins\Events;

class OnContextSave extends OnSiteRefresh
{
}
