<?php
$_lang['setting_langrouter.debug'] = 'Log debug information';
$_lang['setting_langrouter.debug_desc'] = 'Log debug information in MODX system log.';

