<?php
$_lang['setting_langrouter.debug'] = 'Debug';
$_lang['setting_langrouter.debug_desc'] = 'Log debug informations in MODX error log.';
$_lang['setting_langrouter.response_code'] = 'Response Code';
$_lang['setting_langrouter.response_code_desc'] = 'Response code for the redirect to the right context, if the culture key is not set.';
$_lang['setting_langrouter.setcookie'] = 'Set Cookie';
$_lang['setting_langrouter.setcookie_desc'] = 'Override the language detection with a cookie.';

