<?php
/**
 * @package langrouter
 * @subpackage plugin
 */

namespace TreehillStudio\LangRouter\Plugins\Events;

class OnContextRemove extends OnSiteRefresh
{
}
