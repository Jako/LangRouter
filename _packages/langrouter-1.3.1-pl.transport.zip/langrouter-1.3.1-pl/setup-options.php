<?php
/**
 * Setup options
 *
 * @package langrouter
 * @subpackage build
 *
 * @var mixed $object
 * @var array $options
 */

$output = '<style type="text/css">
    #modx-setupoptions-panel { display: none; }
    #modx-setupoptions-form p { margin-bottom: 10px; }
    #modx-setupoptions-form h2 { margin-bottom: 15px; }
</style>
';

$values = array();
switch ($options[xPDOTransport::PACKAGE_ACTION]) {
    case xPDOTransport::ACTION_INSTALL:
        $setting = $modx->getObject('modSystemSetting', array('key' => 'babel.contextDefault'));
        if ($setting != null) {
            $values['contextDefault'] = $setting->get('value');
        }
        unset($setting);

        $output .= '<h2>Install LangRouter</h2>

        <p>Thanks for installing LangRouter. This open source extra was
        developped by Treehill Studio - MODX development in Münsterland.</p>

        <p>During the installation, we will collect some statistical data (the
        hostname, the IP address, the PHP version and the MODX version of your
        MODX installation). Your data will be kept confidential and under no
        circumstances be used for promotional purposes or disclosed to third
        parties.</p>
        
        <p>If you install this package, you are giving us your permission to
        collect, process and use that data for statistical purposes.</p>
        
        <hr>
        
        <p>Please enter the Babel Default Context, which should be served when
        no language is specified in request, eg. \'en\'.<br><br></p>
        
        <label for="babel-contextDefault">Babel Default Context:</label>
        <input type="text" name="contextDefault" id="babel-contextDefault" 
        width="300" value="'.$values['contextDefault'].'">';

        break;
    case xPDOTransport::ACTION_UPGRADE:
        $output .= '<h2>Upgrade LangRouter</h2>

        <p>LangRouter will be upgraded. This open source extra was developped by
        Treehill Studio - MODX development in Münsterland.</p>

        During the upgrade, we will collect some statistical data (the hostname,
        the IP address, the PHP version, the MODX version of your MODX
        installation and the previous installed version of this extra package).
        Your data will be kept confidential and under no circumstances be used
        for promotional purposes or disclosed to third parties.</p>

        <p>If you upgrade this package, you are giving us your permission to
        collect, process and use that data for statistical purposes.</p>';

        break;
    case xPDOTransport::ACTION_UNINSTALL:
        break;
}

return $output;
